Game of Life, written by John Sullivan, Sofia Rossi, and William Ross. 

To start the game, run the program in the command line using 'python gameOfLife.py'
From here, you'll be prompted to enter if you want a custom board size. If yes, enter a board width and height and # of generations.
Otherwise, just enter the number of generations you want to see and the board size will be a default 10x10. 
After that, you're done!